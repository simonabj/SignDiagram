const module = "web3d";
const prerelease = false;
const startDelay = 0;
const marginTop = 0;
const appOnline = false;
const codebase = "GeoGebra/HTML5/5.0/";