const Properties = {
    version: "0.82.0-Alpha - Offline",
    URLS: {
        ggbCodec: "GeoGebra/HTML5/5.0/",
    }
};